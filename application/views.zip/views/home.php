<div class="container">
  <div class="row">
    <br>
    <div class="col-md-12">
      <div class="well">
        <div class="media">
          <a class="pull-left">
           <img src="<?php echo base_url();?>assets/img/md.png" class="media-object" style="width:64px;" alt="" />
         </a>
         <div class="media-body">
          <h2 class="media-heading" align="center">Selamat datang, <?php echo $this->session->userdata('namalengkap');?></h2>
          <h2 align="center">Sistem Informasi</h2>
          <h2 align="center">Praktik Dokter dr. Hj. Siti Sundari, SpM,. Mkes</h2>
          <h4 align="center">Jln. Soeradjitirtonegoro No.67, Bendogantungan, Klaten</h4>
        </div>
      </div>
    </div>
            <!-- <blockquote>
              <h2>
                <p align="center">Selamat datang, <?php echo $this->session->userdata('namalengkap');?></p> 
                <p align="center">SISTEM INFORMASI PRAKTIK DOKTER  </p>
                <p align="center">dr. Hj. Siti Sundari, SpM,. Mkes  </p>
              </h2>
            </blockquote>-->
          </div>
        </div>
      </div>    